// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
var firebaseConfig = {
	apiKey: "AIzaSyAHI6CbIfPwhHTgmptbvDk2Sy-jfyjC3xU",
	authDomain: "mississisppi-dfb4f.firebaseapp.com",
	projectId: "mississisppi-dfb4f",
	storageBucket: "mississisppi-dfb4f.appspot.com",
	messagingSenderId: "84070718942",
	appId: "1:84070718942:web:2ae8d4821416d7eacc114f",
	measurementId: "G-X1Z510FKPH"
};
// Initialize Firebase
firebase.initializeApp(firebaseConfig);

// If firebase.analytics can be used here, load it (firebase analytics can't be used if you are running it locally).
firebase.analytics.isSupported().then((isSupported) => {
	if (isSupported) {
		analytics = firebase.analytics();
	}
})

console.log(firebase);

chrome.runtime.onMessage.addListener((msg, sender, response) => {
		
	if(msg.command == "fetch"){
		//
		var domain = msg.data.domain;
		console.log('domain:', domain);
		var enc_domain = btoa(domain);
		firebase.database().ref('/domain/' + enc_domain).once('value').then(function(snapshot){
			response({type: "result", status: "success", data: snapshot.val(), request: msg});
		});
	}
	
	//submit coupon data
	if(msg.command == "post"){
		var domain = msg.data.domain;
		var enc_domain = btoa(domain);
		var code = msg.data.code;
		var desc = msg.data.desc;
		
		try{
			
			var newPost = firebase.database().ref('/domain/'+enc_domain).push().set({
				code: code,
				description: desc
			});
			
		var postId = newPost.key;	
		response({type: "result", status: "success", data: postId, request:msg});
			
		}catch(e){
			console.log('error:', e);
			response({type: "result", status: "error", data: e, request:msg});
		}
	}	
	
return true;	
})



