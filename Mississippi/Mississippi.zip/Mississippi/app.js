// alert('Yeet from Mississippi!')
// get current domain
var domain = window.location.hostname;
domain = domain.replace('http://', '').replace('https://', '').replace('www.', '').split(/[/?#]/)[0];

chrome.runtime.sendMessage({command: "fetch", data: {domain: domain}}, (response) => {
	parseCoupons(response.data, domain);
});

var submitCoupon = function(code, desc, domain){
	console.log('submit coupon', {code: code, desc: desc, domain: domain});
	chrome.runtime.sendMessage({command: "post", data: {code: code, desc: desc, domain: domain}}, (response) => {
		submitCoupon_callback(response.data, domain);
	});
}

var parseCoupons = function(coupons, domain) {

	try{
		var couponHTML = '';
		for( var key in coupons ){
			var coupon = coupons[key];
			//coupons.forEach(function(coupon, index){
			couponHTML += '<li><span class="code">'+coupon.code+'</span>'
			+'<p>➡ '+coupon.description+'</p></li>';
		}
		if(couponHTML == ''){
			couponHTML = '<p>I can\'t find an American made alternatives for this product.</p>';
		}
		var couponDisplay = document.createElement('div');
		couponDisplay.className = '_coupon__list';
		couponDisplay.innerHTML = '<h1>Mississippi</h1>' //'<div class="submit-button">Submit Coupon</div>'
		+'<p><strong>Before you check out!\n</strong>'
		+'Consider these American made alternatives to what you are about to purchase. '// <strong>'+domain+'</strong></p>'
		+'Click on an American made alternative to add it to your cart!</p>'
		+'<ul>'+couponHTML+'</ul>';
		couponDisplay.style.display = 'block';
		document.body.appendChild(couponDisplay);
		
		var couponButton = document.createElement('div');
		couponButton.className = '_coupon__button';
		//couponButton.innerHTML = 'C';
		couponButton.innerHTML = '<img src="https://coolhandsquid.github.io/assets/img/squid/coolhandsquid.png" alt="" style=width:85%>';
		document.body.appendChild(couponButton);
		
		createEvents();
	
	}catch(e){
		console.log('no coupon found for this domain', e);
	}
}


var copyToClipboard = function(str){
  var input = document.createElement('textarea');
  input.innerHTML = str;
  document.body.appendChild(input);
  input.select();
  var result = document.execCommand('copy');
  document.body.removeChild(input);
  return result;
}

var createEvents = function(){
	
	document.querySelectorAll('._coupon__list .code').forEach(codeItem => {
		codeItem.addEventListener('click', event => {
		var codeStr = codeItem.innerHTML;
		copyToClipboard(codeStr);
		});
	});		
	
	document.querySelector('._coupon__button').addEventListener('click', function(event){
		if(document.querySelector('._coupon__list').style.display == 'block'){
			document.querySelector('._coupon__list').style.display = 'none';
		}else{
			document.querySelector('._coupon__list').style.display = 'block';
		}
	});
}